#!/bin/sh
chmod 777 pwn
mv -f pwn /pwn/pwn
chmod 777 /pwn/pwn