#!/bin/sh
mv -f ProxyAdapter.php /var/www/html/vendor/symfony/symfony/src/Symfony/Component/Cache/Adapter/ProxyAdapter.php
